docker build -t spring-java-app .
docker run -d -p 8080:8080 spring-java-app

